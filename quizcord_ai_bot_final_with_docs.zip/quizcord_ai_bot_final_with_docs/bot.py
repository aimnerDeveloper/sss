
import os
import discord
from discord.ext import commands
from dotenv import load_dotenv
from retriever import get_best_answer

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
CHANNEL_IDS = os.getenv("CHANNEL_IDS", "").split(",")
GUILD_IDS = os.getenv("GUILD_IDS", "").split(",")

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"{bot.user} is now running!")

@bot.event
async def on_message(message):
    print("Message received from:", message.author.name)
    print("Channel:", message.channel.id, "Guild:", message.guild.id)
    print("Has components:", bool(message.components))

    if (
        str(message.channel.id) not in CHANNEL_IDS or
        str(message.guild.id) not in GUILD_IDS or
        message.author.name != "Quizcord"
    ):
        return

    if not message.components:
        return

    question = message.embeds[0].title if message.embeds else message.content
    options = [button.label for row in message.components for button in row.children]

    print("Extracted question:", question)
    print("Extracted options:", options)

    best_answer = get_best_answer(question, options)
    print("Final answer:", best_answer)

    for row in message.components:
        for button in row.children:
            print("Evaluating button:", button.label)
            if button.label.lower() == best_answer.lower():
                try:
                    await message.click(button)
                    print(f"✅ Clicked: {button.label}")
                    return
                except Exception as e:
                    print("❌ Error clicking button:", e)
