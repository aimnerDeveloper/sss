
import os
import json
import openai
import google.generativeai as genai
from dotenv import load_dotenv
import chromadb
from chromadb.utils import embedding_functions
import difflib

load_dotenv()

openai.api_key = os.getenv("OPENAI_API_KEY")
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
PREFERRED_AI = os.getenv("PREFERRED_AI", "openai")

client = chromadb.Client()
collection = client.get_or_create_collection("irys_docs",
    embedding_function=embedding_functions.OpenAIEmbeddingFunction(api_key=openai.api_key)
)

DOCS_PATH = "./docs"

def load_and_embed_docs():
    print("📚 Indexing documents...")
    for fname in os.listdir(DOCS_PATH):
        if fname.endswith(".txt"):
            with open(os.path.join(DOCS_PATH, fname), "r") as f:
                content = f.read()
                collection.add(documents=[content], ids=[fname])
    print("✅ Embedding complete.")

load_and_embed_docs()

def get_best_answer(question, options):
    print("🔍 Looking up context for question...")
    results = collection.query(query_texts=[question], n_results=3)
    docs = results['documents'][0] if results['documents'] else []
    context = "\n".join(docs)

    prompt = f"""
You're an expert at Irys-based trivia. Use the context below to answer the question with the best option.

Context:
{context}

Question: {question}
Options: {options}

Answer with the best option text only.
"""

    if PREFERRED_AI == "gemini":
        model = genai.GenerativeModel("gemini-pro")
        res = model.generate_content(prompt)
        raw_response = res.text
    else:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        raw_response = response.choices[0].message["content"]

    print("💬 AI raw response:", raw_response)

    match = extract_answer(raw_response, options)
    print("🎯 Matched answer:", match)
    return match

def extract_answer(text, options):
    match = difflib.get_close_matches(text.strip(), options, n=1, cutoff=0.4)
    return match[0] if match else options[0]
